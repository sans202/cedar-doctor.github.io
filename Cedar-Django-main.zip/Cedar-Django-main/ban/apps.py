from django.apps import AppConfig


class BanConfig(AppConfig):
    name = 'ban'
