# Cedar-Django

https://youtu.be/uUiJCG06bdA

Alright, I know I will eventually have to write the documentation, but fuuuuuuck I really don't want to do it.

It's a standard Django app, You'll have to somehow set it up either with python3 manage.py runserver, or through nginx or whatever.
